# Energized Power 1.20.1-2.15.22 (Forge) + Elite backport

Versão modificada do Energized Power 2.15.22. **Substitui** o .jar original (mesmo mod id `energizedpower`,
mesmos IDs de blocos/itens, então mundos e itens existentes continuam funcionando).
NÃO use junto com o addon `ep_elite_upgrades` (ele foi substituído por esta versão).

## Novidades (valores/receitas/texturas da 3.0.5)
- Speed, Energy Efficiency, Energy Capacity: níveis VI, VII, VIII
- Moon Light IV e V; Extraction Depth VI; Extraction Range VI
- **Energy Production** I a VIII (novo tipo de upgrade, multiplica a geração)
- **Solar Panel VII** (pico 524.288 FE/t, capacidade 4.194.304, transferência 2.097.152)
- **Todos os Solar Panels (I a VII) agora têm 3º slot** para Energy Production (GUI nova, textura da 3.x).
  Módulos que já estavam nos 2 primeiros slots continuam lá.
- Materiais Elite: Crystallized Lapis, Crystallized Alloy, Energized Alloy (lingote/placa), Coolant Cell,
  Superconductor, Quantum Processing Unit, Elite Solar Cell, Elite Upgrade Module (+ receitas das máquinas).

## Avisos
- Energized Alloy gasta ~84 mil FE/tick no Energizer: use Energy Capacity IV ou superior nele.
- O Energizer NÃO tem versão evoluída na 3.x (só Auto Crafter, Battery Box, Charger, Powered Furnace,
  Uncharger e Minecart Charger/Uncharger ganharam versão Elite).
- Energy Production nos geradores (Coal Engine, Heat Generator, Thermal Generator) NÃO foi adicionado:
  eles só têm 1 slot de upgrade na 2.15.22 e precisariam de novas GUIs.
- Novos valores aparecem em `config/energizedpower-common.toml` (o mod faz backup do arquivo antigo).
- Não incluídos: máquinas Elite, páginas do livro, advancements das receitas novas.

## Compilar
GitHub Actions: suba o projeto (ou o zip + build_elite.yml) e rode "Build mod".
O .jar sai com o nome `energizedpower-elite-1.20.1-2.15.22-forge.jar`.
