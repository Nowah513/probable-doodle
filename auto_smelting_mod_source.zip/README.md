# Auto Smelting Enchantment (Forge 1.20.1)

Reescrita do encantamento **Auto Smelt** com o MESMO ID do mod original
(`auto_smelting:auto_smelt`). Ferramentas e livros que já têm o encantamento
continuam com ele depois da troca.

## Como funciona
- Ao quebrar um bloco com uma picareta encantada, cada drop que tenha receita de
  fornalha ou alto-forno (smelting/blasting) é trocado pelo resultado da receita.
- Fortune continua valendo (a quantidade já vem multiplicada antes de fundir).
- Silk Touch é incompatível (igual ao original) e, se vier de outro mod, não funde.
- Por padrão só funde **minérios** (vanilla e de outros mods, como Dense Ores).
  Não transforma cobblestone em pedra, areia em vidro etc.

## Config (config/auto_smelting-common.toml)
- `onlyOres = true`  -> só minérios. `false` funde qualquer drop com receita.
- `extraOreBlocks = []` -> blocos/tags extras tratados como minério.
  Ex.: `["dense_ores:algum_bloco", "#forge:ores/iron"]`. F3 olhando o bloco mostra o ID.
- `debugLogging = false` -> `true` registra no latest.log blocos que NÃO foram
  reconhecidos como minério mas têm drop fundível (ajuda a achar o ID certo).

## IMPORTANTE
Use o MESMO mod id do original, então **remova o .jar antigo** da pasta mods
(dois mods com o mesmo id fazem o jogo fechar ao iniciar).
Os outros itens/blocos do mod antigo (portas de obsidiana, Void Totem etc.) NÃO existem aqui.

## Compilar
### GitHub Actions (não instala nada)
1. Suba o projeto inteiro em um repositório (`.github/workflows/build.yml` já está incluso).
2. Aba **Actions** -> rode "Build mod" -> baixe o artefato `auto-smelting-jar`.

### No PC
1. Instale o JDK 17.
2. Instale o Gradle e, em uma pasta vazia, rode `gradle wrapper --gradle-version 8.1.1`;
   copie `gradlew`, `gradlew.bat` e a pasta `gradle` para dentro deste projeto.
3. Na pasta do projeto: `./gradlew build` (Windows: `gradlew.bat build`).
4. O .jar fica em `build/libs/`.
