package com.autosmelting;

import java.util.List;

import net.minecraftforge.common.ForgeConfigSpec;

public final class AutoSmeltConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue ONLY_ORES;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> EXTRA_ORE_BLOCKS;
    public static final ForgeConfigSpec.BooleanValue DEBUG_LOGGING;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        ONLY_ORES = b
                .comment("If true (default), only ore blocks are smelted (vanilla and modded ores).",
                        "If false, ANY block drop with a furnace recipe is smelted (cobblestone -> stone, sand -> glass, logs -> charcoal...).")
                .define("onlyOres", true);

        EXTRA_ORE_BLOCKS = b
                .comment("Extra blocks that must count as ore. Use block IDs (e.g. \"modid:some_block\") or block tags starting with # (e.g. \"#forge:ores/iron\").",
                        "Use this if a modded ore is not being smelted. Press F3 while looking at a block to see its ID.")
                .defineListAllowEmpty("extraOreBlocks", List.<String>of(), o -> o instanceof String);

        DEBUG_LOGGING = b
                .comment("Logs to latest.log when an Auto Smelt tool breaks a block that has smeltable drops but was not recognised as ore.")
                .define("debugLogging", false);

        SPEC = b.build();
    }

    private AutoSmeltConfig() {
    }
}
