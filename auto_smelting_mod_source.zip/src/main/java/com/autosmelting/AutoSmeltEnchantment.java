package com.autosmelting;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.Enchantments;

/**
 * Same properties as the original enchantment: Uncommon, main hand,
 * cost 1 + 10*level (min) / 6 + 10*level (max), max level 1,
 * treasure only, incompatible with Silk Touch.
 * Applicable to every pickaxe (the original listed 5 vanilla pickaxes).
 */
public class AutoSmeltEnchantment extends Enchantment {
    public static final EnchantmentCategory CATEGORY =
            EnchantmentCategory.create("auto_smelting_auto_smelt", item -> item instanceof PickaxeItem);

    public AutoSmeltEnchantment() {
        super(Rarity.UNCOMMON, CATEGORY, new EquipmentSlot[]{EquipmentSlot.MAINHAND});
    }

    @Override
    public int getMinCost(int level) {
        return 1 + level * 10;
    }

    @Override
    public int getMaxCost(int level) {
        return 6 + level * 10;
    }

    @Override
    protected boolean checkCompatibility(Enchantment other) {
        return super.checkCompatibility(other) && other != Enchantments.SILK_TOUCH;
    }

    @Override
    public boolean isTreasureOnly() {
        return true;
    }
}
