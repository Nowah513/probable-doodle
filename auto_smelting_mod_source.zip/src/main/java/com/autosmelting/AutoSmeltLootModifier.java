package com.autosmelting;

import java.util.Optional;
import java.util.function.Supplier;

import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;

import com.google.common.base.Suppliers;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SmeltingRecipe;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.common.loot.LootModifier;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Global loot modifier: when a block is broken with a tool that has Auto Smelt,
 * every drop that has a furnace (smelting) recipe is replaced by the recipe result.
 * Because it works on the final drop list, Fortune is already applied and
 * modded blocks (e.g. Dense Ores) are handled without a hard-coded block list.
 */
public class AutoSmeltLootModifier extends LootModifier {
    private static final Logger LOGGER = LogUtils.getLogger();

    public static final Supplier<Codec<AutoSmeltLootModifier>> CODEC =
            Suppliers.memoize(() -> RecordCodecBuilder.create(inst -> codecStart(inst).apply(inst, AutoSmeltLootModifier::new)));

    public AutoSmeltLootModifier(LootItemCondition[] conditions) {
        super(conditions);
    }

    @Override
    protected @NotNull ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> generatedLoot, LootContext context) {
        ItemStack tool = context.getParamOrNull(LootContextParams.TOOL);
        if (tool == null || tool.isEmpty()) {
            return generatedLoot;
        }
        if (EnchantmentHelper.getItemEnchantmentLevel(AutoSmeltingMod.AUTO_SMELT.get(), tool) <= 0) {
            return generatedLoot;
        }
        // Only blocks being broken (not mob drops, chests, fishing...).
        BlockState state = context.getParamOrNull(LootContextParams.BLOCK_STATE);
        if (state == null) {
            return generatedLoot;
        }
        // Silk Touch means the player wants the block itself.
        if (EnchantmentHelper.getItemEnchantmentLevel(Enchantments.SILK_TOUCH, tool) > 0) {
            return generatedLoot;
        }

        ServerLevel level = context.getLevel();

        if (AutoSmeltConfig.ONLY_ORES.get() && !OreFilter.isOre(state)) {
            if (AutoSmeltConfig.DEBUG_LOGGING.get()) {
                for (ItemStack stack : generatedLoot) {
                    if (findResult(stack, level) != null) {
                        LOGGER.info("[Auto Smelt] Not treated as ore: {} (drops {}). Add it to extraOreBlocks in the config to smelt it.",
                                ForgeRegistries.BLOCKS.getKey(state.getBlock()), ForgeRegistries.ITEMS.getKey(stack.getItem()));
                        break;
                    }
                }
            }
            return generatedLoot;
        }

        ObjectArrayList<ItemStack> result = new ObjectArrayList<>();
        for (ItemStack stack : generatedLoot) {
            ItemStack smelted = findResult(stack, level);
            if (smelted == null) {
                result.add(stack);
                continue;
            }
            int total = smelted.getCount() * stack.getCount();
            int max = Math.max(1, smelted.getMaxStackSize());
            while (total > 0) {
                int n = Math.min(total, max);
                ItemStack out = smelted.copy();
                out.setCount(n);
                result.add(out);
                total -= n;
            }
        }
        return result;
    }

    /** Returns the furnace result for ONE item of the given stack, or null if it has no smelting recipe. */
    private static ItemStack findResult(ItemStack stack, ServerLevel level) {
        if (stack.isEmpty()) {
            return null;
        }
        ItemStack single = stack.copy();
        single.setCount(1);
        Optional<SmeltingRecipe> recipe = level.getRecipeManager()
                .getRecipeFor(RecipeType.SMELTING, new SimpleContainer(single), level);
        if (recipe.isEmpty()) {
            return null;
        }
        ItemStack out = recipe.get().getResultItem(level.registryAccess());
        if (out.isEmpty()) {
            return null;
        }
        return out;
    }

    @Override
    public Codec<? extends IGlobalLootModifier> codec() {
        return CODEC.get();
    }
}
