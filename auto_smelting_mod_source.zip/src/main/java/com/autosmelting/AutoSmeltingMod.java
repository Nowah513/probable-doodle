package com.autosmelting;

import com.mojang.serialization.Codec;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Mod id and registry name are intentionally identical to the original
 * "Auto Smelting Enchantment" mod: the enchantment is "auto_smelting:auto_smelt".
 * That keeps every tool/book that already has the enchantment working.
 */
@Mod(AutoSmeltingMod.MODID)
public class AutoSmeltingMod {
    public static final String MODID = "auto_smelting";

    public static final DeferredRegister<Enchantment> ENCHANTMENTS =
            DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, MODID);

    public static final RegistryObject<Enchantment> AUTO_SMELT =
            ENCHANTMENTS.register("auto_smelt", AutoSmeltEnchantment::new);

    public static final DeferredRegister<Codec<? extends IGlobalLootModifier>> LOOT_MODIFIERS =
            DeferredRegister.create(ForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS, MODID);

    public static final RegistryObject<Codec<? extends IGlobalLootModifier>> AUTO_SMELT_MODIFIER =
            LOOT_MODIFIERS.register("auto_smelt", AutoSmeltLootModifier.CODEC);

    public AutoSmeltingMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ENCHANTMENTS.register(modBus);
        LOOT_MODIFIERS.register(modBus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, AutoSmeltConfig.SPEC);
    }
}
