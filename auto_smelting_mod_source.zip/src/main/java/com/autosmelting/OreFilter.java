package com.autosmelting;

import java.util.List;
import java.util.regex.Pattern;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.Tags;
import net.minecraftforge.registries.ForgeRegistries;

/** Decides whether a broken block counts as an "ore". */
public final class OreFilter {
    // "iron_ore", "deepslate_iron_ore", "dense_iron_ore", "ore_iron"... but not "core" or "restore".
    private static final Pattern ORE_NAME = Pattern.compile("(^|_)ores?(_|$)|ancient_debris");

    private static final List<TagKey<Block>> VANILLA_ORE_TAGS = List.of(
            BlockTags.COAL_ORES,
            BlockTags.IRON_ORES,
            BlockTags.COPPER_ORES,
            BlockTags.GOLD_ORES,
            BlockTags.REDSTONE_ORES,
            BlockTags.LAPIS_ORES,
            BlockTags.DIAMOND_ORES,
            BlockTags.EMERALD_ORES);

    public static boolean isOre(BlockState state) {
        if (state.is(Tags.Blocks.ORES)) {
            return true;
        }
        for (TagKey<Block> tag : VANILLA_ORE_TAGS) {
            if (state.is(tag)) {
                return true;
            }
        }

        ResourceLocation id = ForgeRegistries.BLOCKS.getKey(state.getBlock());
        if (id == null) {
            return false;
        }
        if (ORE_NAME.matcher(id.getPath()).find()) {
            return true;
        }

        for (String entry : AutoSmeltConfig.EXTRA_ORE_BLOCKS.get()) {
            if (entry.startsWith("#")) {
                ResourceLocation tagId = ResourceLocation.tryParse(entry.substring(1));
                if (tagId != null && state.is(TagKey.create(Registries.BLOCK, tagId))) {
                    return true;
                }
            } else {
                ResourceLocation blockId = ResourceLocation.tryParse(entry);
                if (blockId != null && blockId.equals(id)) {
                    return true;
                }
            }
        }
        return false;
    }

    private OreFilter() {
    }
}
